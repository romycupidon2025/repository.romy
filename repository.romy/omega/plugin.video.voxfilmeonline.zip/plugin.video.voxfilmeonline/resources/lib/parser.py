import requests
import re
import time
import os
import json
import urllib.parse
from urllib.parse import urlparse, urlunparse
import html  # Importăm modulul html pentru decodificare

# User-Agent pentru a evita blocarea de către server
headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
}

# URL-ul de bază al site-ului
base_url = 'https://voxfilmeonline.biz'

# Creăm o sesiune
session = requests.Session()
session.headers.update(headers)

# Expresii regulate pentru extragerea categoriilor și URL-urilor
category_pattern = re.compile(r'<a href="(https://voxfilmeonline\.biz/category/filme-online/[^"]+)"[^>]*>([^<]+)</a>', re.DOTALL)
title_pattern = re.compile(
    r'<h2\s+class="hcover-title">\s*(.*?)\s*(?:\d{4}.*?)?\s*</h2>',
    re.IGNORECASE | re.DOTALL
)
url_pattern = re.compile(r'<a href="(https://voxfilmeonline\.biz/(?!release-year|category)[^"]+)"', re.DOTALL)

# Expresii regulate pentru detalii de pe pagina filmului
poster_pattern = re.compile(
    r'<img\s+[^>]*itemprop="image"[^>]*src="(https://voxfilmeonline\.biz/wp-content/uploads/[^"]+\.(?:jpg|webp))"',
    re.IGNORECASE
)
description_pattern = re.compile(
    r'<div\s+itemprop="description"\s+class="movie-description">\s*<p>(.*?)</p>\s*</div>',
    re.IGNORECASE | re.DOTALL
)
genre_pattern = re.compile(r'<div itemprop="genre">(.*?)</div>', re.DOTALL)
release_pattern = re.compile(r'<div class="single_movie_info">\s*<span class="release">Lansat:\s*</span>\s*(.*?)\s*</div>', re.DOTALL)
trailer_pattern = re.compile(r'<iframe.*?src="(https://www.youtube.com/embed/[^"]+)"', re.DOTALL)
video_pattern = re.compile(
    r'<iframe\s+[^>]*src="(https?://[^"]+)"',
    re.IGNORECASE
)
mixdrop_pattern = re.compile(
    r'<iframe\s+[^>]*src="(//mixdrop\.is/e/[^"]+)"',
    re.IGNORECASE
)

# Funcție pentru a verifica validitatea cache-ului
def is_cache_valid(cache_file, max_age_hours=24):
    if not os.path.exists(cache_file):
        return False
    file_mod_time = os.path.getmtime(cache_file)
    current_time = time.time()
    # Convertim orele în secunde
    max_age_seconds = max_age_hours * 3600
    if (current_time - file_mod_time) < max_age_seconds:
        return True
    return False

# Funcție pentru a extrage categoriile
def extract_categories(base_url):
    try:
        response = session.get(base_url)
        response.raise_for_status()
        html_content = response.text
        categories = category_pattern.findall(html_content)
        return [{'url': url, 'name': name} for url, name in categories]
    except requests.RequestException as e:
        print(f"Error fetching categories from {base_url}: {e}")
        return []

# Funcție pentru decodificarea entităților HTML folosind html.unescape
def decode_html_entities(text):
    return html.unescape(text)

# Funcție pentru a extrage detaliile unui film de pe pagina sa folosind regex
def extract_movie_details(movie_url):
    try:
        movie_response = session.get(movie_url)
        movie_response.raise_for_status()
        movie_html_content = movie_response.text

        # Extrage posterul
        poster_match = poster_pattern.search(movie_html_content)
        poster = poster_match.group(1).strip() if poster_match else "N/A"

        # Extrage descrierea
        description_match = description_pattern.search(movie_html_content)
        description = description_match.group(1).strip() if description_match else "N/A"
        description = html.unescape(description)

        # Extrage genurile
        genre_match = genre_pattern.search(movie_html_content)
        if genre_match:
            genres = re.findall(r'rel="category tag">(.*?)</a>', genre_match.group(1), re.IGNORECASE)
            genre = ', '.join(genres)
            genre = html.unescape(genre)
        else:
            genre = "N/A"

        # Extrage data lansării
        release_match = release_pattern.search(movie_html_content)
        release_date = release_match.group(1).strip() if release_match else "N/A"
        release_date = html.unescape(release_date)

        # Extrage trailer-ul
        trailer_match = trailer_pattern.search(movie_html_content)
        trailer_url = trailer_match.group(1) if trailer_match else "N/A"

        # Extrage sursele video
        video_matches = video_pattern.findall(movie_html_content)
        mixdrop_matches = mixdrop_pattern.findall(movie_html_content)

        # Filtrăm URL-urile corecte pentru sursele video
        valid_video_urls = []
        for url in video_matches:
            if not re.search(r'youtube\.com|voxfilmeonline\.biz', url, re.IGNORECASE):
                if url.startswith("//"):
                    url = "https:" + url
                valid_video_urls.append(url)

        # Adăugăm URL-urile de pe Mixdrop
        for url in mixdrop_matches:
            if url.startswith("//"):
                url = "https:" + url
            if not re.search(r'youtube\.com|voxfilmeonline\.biz', url, re.IGNORECASE):
                valid_video_urls.append(url)

        # Eliminăm duplicatele
        valid_video_urls = list(set(valid_video_urls)) if valid_video_urls else ["N/A"]

        # Înlocuim domeniul "realyplayonli.xyz" cu "waaw.ac"
        valid_video_urls = [
            replace_domain(url, "realyplayonli.xyz", "waaw.ac") if "realyplayonli.xyz" in url else url
            for url in valid_video_urls
        ]

        return poster, description, genre, release_date, trailer_url, valid_video_urls

    except requests.RequestException as e:
        return "N/A", "N/A", "N/A", "N/A", "N/A", ["N/A"]

# Funcție pentru a extrage datele de pe o pagină de filme
def extract_page_movies(page_url):
    try:
        response = session.get(page_url)
        response.raise_for_status()
        html_content = response.text

        titles = title_pattern.findall(html_content)
        urls = url_pattern.findall(html_content)

        # Debug: Afișăm extragerile brute pentru a înțelege problema
        print(f'Titles: {titles}')
        print(f'URLs: {urls}')

        movies = []
        for title, url in zip(titles, urls):
            if "release-year" in url or "category" in url:
                continue
            poster, description, genre, release_date, trailer_url, video_urls = extract_movie_details(url)
            cleaned_title = re.sub(r'\b(?:film|online|subtitrat|HD)\b|\s*\d{4}.*', '', title, flags=re.IGNORECASE).strip()
            cleaned_title = decode_html_entities(cleaned_title)  # Decodifică entitățile HTML
            movies.append({
                'Title': cleaned_title,
                'Poster': poster,
                'Description': description,
                'Genre': genre,
                'Release Date': release_date,
                'Trailer': trailer_url,
                'Videos': video_urls,
                'URL': url
            })
            time.sleep(1)  # Așteptăm 1 secundă între cereri pentru a evita blocarea

        return movies

    except requests.RequestException as e:
        print(f"Error fetching movies from {page_url}: {e}")
        return []

#from urllib.parse import urlparse, urlunparse

def replace_domain(url, old_domain, new_domain):
    parsed = urlparse(url)
    if old_domain in parsed.netloc:
        # Înlocuiește netloc-ul cu noul domeniu
        new_netloc = parsed.netloc.replace(old_domain, new_domain)
        parsed = parsed._replace(netloc=new_netloc)
        return urlunparse(parsed)
    return url


# Funcție pentru a obține filmele din cache
def get_cached_movies(cache_file):
    if is_cache_valid(cache_file):
        try:
            with open(cache_file, 'r', encoding='utf-8') as file:
                return json.load(file)
        except (IOError, json.JSONDecodeError) as e:
            print(f"Error reading cache file {cache_file}: {e}")
            return None
    return None

# Funcție pentru a salva filmele în cache
def cache_movies(movies, cache_file):
    try:
        with open(cache_file, 'w', encoding='utf-8') as file:
            json.dump(movies, file, ensure_ascii=False, indent=4)
    except IOError as e:
        print(f"Error writing to cache file {cache_file}: {e}")

# Funcție pentru a căuta filme
def search_movies(query):
    search_url = f"{base_url}/?s={urllib.parse.quote(query)}"
    return extract_page_movies(search_url)

# Exemplu de utilizare
if __name__ == "__main__":
    cache_file = 'movies_cache.json'

    # Încearcă să obții filmele din cache
    movies = get_cached_movies(cache_file)

    if movies is None:
        # Dacă cache-ul nu este valid sau nu există, extrage din site
        print("Fetching fresh data...")
        categories = extract_categories(base_url)
        print(f"Found categories: {categories}")

        if categories:
            first_category_url = categories[0]['url']
            print(f"Extracting movies from category: {categories[0]['name']} ({first_category_url})")
            movies = extract_page_movies(first_category_url)
            print(f"Extracted {len(movies)} movies.")

            # Salvează datele în cache
            cache_movies(movies, cache_file)
        else:
            print("No categories found.")
    else:
        print("Loaded movies from cache.")

    # Afișează filmele
    for movie in movies:
        print(json.dumps(movie, ensure_ascii=False, indent=4))

#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import re
import json
from base64 import b64decode
from urllib.parse import urlparse
import requests
from bs4 import BeautifulSoup
from Cryptodome.Cipher import Blowfish


def get_primewire_sources(
    imdb_id: str,
    is_tv: bool = False,
    season: int = 1,
    episode: int = 1,
    base_url: str = "https://www.primewire.mov",
    timeout: int = 20,
):
    """
    Returnează o listă de surse: [{host, link, key, via}], folosind:
    - #user-data[v] -> decrypt (Blowfish ECB, key = ultimele 10 caractere din string)
    - token extras din HTML/cookies
    - /links/go/<key>?token=... (fallback: /links/gos/<key>)
    - suport atât pentru 30x redirect (Location), cât și răspuns JSON
    """

    # ---------- helpers ----------
    class BlowfishDecryptor:
        def __init__(self, key: str):
            self.cipher = Blowfish.new(key.encode("utf-8"), Blowfish.MODE_ECB)

        def decrypt(self, data_b64: str) -> str:
            data = b64decode(data_b64)
            # Blowfish ECB cere multiplu de 8
            if len(data) % 8 != 0:
                data += b"\x00" * (8 - (len(data) % 8))
            plain = self.cipher.decrypt(data).rstrip(b"\x00")
            return plain.decode("utf-8", errors="ignore")

    def decrypt_keys(encrypted_string: str):
        key = encrypted_string[-10:]
        payload_b64 = encrypted_string[:-10]
        plain = BlowfishDecryptor(key).decrypt(payload_b64)
        # bucăți de 1..5 (comportament din codul tău)
        chunks = re.findall(r".{1,5}", plain)
        # dedupe păstrând ordinea
        seen, out = set(), []
        for c in chunks:
            if c and c not in seen:
                seen.add(c)
                out.append(c)
        return out

    def extract_token(html: str, session: requests.Session):
        # caută variabile JS comune: window.linkToken / token / data-token
        for pat in (
            r'(?:window\.)?(?:linkToken|token)\s*[:=]\s*[\'"]([^\'"]+)',
            r'data-token=["\']([^"\']+)',
        ):
            m = re.search(pat, html)
            if m:
                return m.group(1)
        # fallback: cookie
        return session.cookies.get("token") or session.cookies.get("linkToken") or ""

    def resolve_key(session: requests.Session, base: str, key: str, token: str):
        paths = (f"/links/go/{key}", f"/links/gos/{key}")
        params = {}
        if token:
            params["token"] = token
        # uneori util pentru embed-uri
        params["embed"] = "true"

        for p in paths:
            url = f"{base}{p}"
            r = session.get(url, params=params, allow_redirects=False, timeout=timeout)
            # 30x → Location (cazul cel mai frecvent)
            if 300 <= r.status_code < 400 and "Location" in r.headers:
                final_url = r.headers["Location"]
                host = urlparse(final_url).netloc
                return {"host": host, "link": final_url, "key": key, "via": "redirect"}

            # Uneori răspunde JSON
            ctype = r.headers.get("Content-Type", "")
            text = r.text or ""
            if "application/json" in ctype or (text.startswith("{") and text.endswith("}")):
                try:
                    data = r.json()
                except Exception:
                    data = {}
                link = data.get("link") or data.get("url") or data.get("Location")
                if link:
                    host = data.get("host") or urlparse(link).netloc
                    return {"host": host, "link": link, "key": key, "via": "json"}
        raise RuntimeError("nu s-a putut rezolva key")

    # ---------- request embed ----------
    session = requests.Session()
    session.headers.update(
        {
            "User-Agent": "Mozilla/5.0",
            "Referer": base_url,
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        }
    )

    if is_tv:
        embed_url = f"{base_url}/embed/tv?imdb={imdb_id}&season={season}&episode={episode}"
    else:
        embed_url = f"{base_url}/embed/movie?imdb={imdb_id}"

    resp = session.get(embed_url, timeout=timeout)
    resp.raise_for_status()
    html = resp.text

    # ---------- v din #user-data ----------
    soup = BeautifulSoup(html, "html.parser")
    el = soup.find("span", {"id": "user-data"})
    if not el or not el.has_attr("v"):
        raise ValueError("Nu am găsit #user-data[v] în embed.")

    encrypted_string = el["v"]
    keys = decrypt_keys(encrypted_string)
    if not keys:
        raise ValueError("Decriptare nereușită sau fără chei.")

    token = extract_token(html, session)

    results = []
    for k in keys:
        try:
            results.append(resolve_key(session, base_url, k, token))
        except Exception as e:
            results.append({"key": k, "error": str(e)})

    return results


# Exemplu de utilizare
if __name__ == "__main__":
    imdb_id = "tt0111161"
    is_tv = False
    season = 1
    episode = 1
    sources = get_primewire_sources(imdb_id, is_tv=is_tv, season=season, episode=episode)

    print("\nSurse video extrase:")
    for i, it in enumerate(sources, 1):
        if "error" in it:
            print(f"#{i} - {it['key']}: ERROR → {it['error']}")
        else:
            print(f"#{i} - {it['host']} ({it['via']}): {it['link']}")

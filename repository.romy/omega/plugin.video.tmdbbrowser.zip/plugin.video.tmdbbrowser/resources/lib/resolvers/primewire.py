#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import re
import json
import time
from base64 import b64decode
from urllib.parse import urlparse
import requests
from bs4 import BeautifulSoup
from Cryptodome.Cipher import Blowfish
from Cryptodome.Util.Padding import unpad


def get_primewire_sources(
    imdb_id: str,
    is_tv: bool = False,
    season: int = 1,
    episode: int = 1,
    base_url: str = "https://www.primewire.tf",
    timeout: int = 20,
    max_retries: int = 3
):
    """
    Returnează o listă de surse: [{host, link, key, via}], folosind:
    - API pentru ID intern
    - #user-data[v] -> decrypt (Blowfish ECB, key = ultimele 10 caractere din string)
    - /links/go/<key> cu headers corespunzătoare și retry pentru 404
    - suport atât pentru 30x redirect (Location), cât și răspuns JSON
    """

    # ---------- helpers ----------
    class BlowfishDecryptor:
        def __init__(self, key: str):
            self.cipher = Blowfish.new(key.encode("utf-8"), Blowfish.MODE_ECB)

        def decrypt(self, data_b64: str) -> str:
            data = b64decode(data_b64)
            try:
                decrypted = self.cipher.decrypt(data)
                # Încercă să elimini padding-ul PKCS7
                decrypted = unpad(decrypted, Blowfish.block_size)
            except ValueError:
                # Dacă padding-ul e deja corect, folosește direct
                pass
            return decrypted.decode("utf-8", errors="ignore")

    def decrypt_keys(encrypted_string: str):
        key = encrypted_string[-10:]
        payload_b64 = encrypted_string[:-10]
        plain = BlowfishDecryptor(key).decrypt(payload_b64)
        # bucăți de 5 caractere (comportament din codul Kotlin)
        chunks = [plain[i:i+5] for i in range(0, len(plain), 5)]
        # dedupe păstrând ordinea
        seen, out = set(), []
        for c in chunks:
            if c and c not in seen:
                seen.add(c)
                out.append(c)
        return out

    def get_internal_id(imdb_id: str, session: requests.Session, base_url: str):
        """Obține ID-ul intern PrimeWire folosind API-ul"""
        search_key = b64decode("bHpRUHNYU0tjRw==").decode("utf-8")

        resp = session.get(
            f"{base_url}/api/v1/show",
            params={"key": search_key, "imdb_id": imdb_id},
            timeout=timeout,
        )
        if resp.status_code != 200:
            raise RuntimeError(f"Failed to get internal ID (status {resp.status_code})")

        try:
            data = resp.json()
        except ValueError:
            data = json.loads(resp.text)

        if "id" not in data:
            raise RuntimeError(f"Response doesn't contain 'id' for imdb_id={imdb_id}")

        return int(float(data["id"]))

    def get_episode_page_url(show_soup: BeautifulSoup, season: int, episode: int, base_url: str):
        """Găsește URL-ul pentru un episod specific"""
        selector = f".show_season[data-id='{season}'] > div > a"
        anchors = show_soup.select(selector)

        ep_link = None
        pattern = re.compile(rf"-episode-{episode}\b", re.IGNORECASE)

        for a in anchors:
            href = a.get("href") or ""
            if pattern.search(href):
                ep_link = href
                break

        if not ep_link:
            raise RuntimeError(f"Could not find episode link for season={season} episode={episode}")

        if not ep_link.startswith("http"):
            ep_link = f"{base_url}{ep_link}"

        return ep_link

    def resolve_key(session: requests.Session, base: str, key: str, referer: str, max_retries: int = 3):
        """Rezolvă o cheie în URL real folosind endpoint-ul /links/go/ cu retry pentru 404"""
        url = f"{base}/links/go/{key}"

        headers = {
            "Referer": referer,
            "Accept": "application/json, text/plain, */*",
            "X-Requested-With": "XMLHttpRequest",
            "User-Agent": "Mozilla/5.0 (X11; Linux x86_64; rv:128.0) Gecko/20100101 Firefox/128.0"
        }

        for attempt in range(max_retries):
            try:
                r = session.get(url, headers=headers, allow_redirects=False, timeout=20)

                # Dacă primim 404, încercăm din nou
                if r.status_code == 404:
                    if attempt < max_retries - 1:
                        time.sleep(1)  # Așteptăm 1 secundă înainte de retry
                        continue
                    else:
                        raise RuntimeError(f"404 Client Error: Not Found after {max_retries} attempts")

                # 30x → Location (cazul cel mai frecvent)
                if 300 <= r.status_code < 400 and "Location" in r.headers:
                    final_url = r.headers["Location"]
                    host = urlparse(final_url).netloc
                    return {"host": host, "link": final_url, "key": key, "via": "redirect"}

                # Răspuns JSON
                ctype = r.headers.get("Content-Type", "")
                text = r.text or ""
                if "application/json" in ctype or (text.startswith("{") and text.endswith("}")):
                    try:
                        data = r.json()
                    except Exception:
                        data = {}
                    link = data.get("link") or data.get("url") or data.get("Location")
                    if link:
                        host = data.get("host") or urlparse(link).netloc
                        return {"host": host, "link": link, "key": key, "via": "json"}

                # Dacă niciuna nu funcționează, aruncă eroare
                raise RuntimeError(f"Status: {r.status_code}, Response: {text[:100]}")

            except Exception as e:
                if attempt < max_retries - 1:
                    time.sleep(1)  # Așteptăm 1 secundă înainte de retry
                    continue
                else:
                    raise RuntimeError(f"Request failed after {max_retries} attempts: {str(e)}")

    def extract_host_info(link_el, idx):
        """Extrage numele hostului și calitatea din elementul HTML"""

        host_name = None
        quality = "HD"  # Default quality

        # Strategii de extragere a numelui hostului
        strategies = [
            lambda: _find_host_in_parents(link_el),
            lambda: _find_host_by_index(link_el, idx),
            lambda: _find_host_in_container(link_el),
        ]

        for strategy in strategies:
            host_name = strategy()
            if host_name and host_name != "unknown":
                break

        # Extrage calitatea dacă este disponibilă
        quality = _extract_quality(link_el)

        return host_name or f"server_{idx}", quality

    def _find_host_in_parents(link_el):
        """Caută numele hostului în părinții elementului"""
        for parent in link_el.parents:
            host_el = parent.select_one(".version-host")
            if host_el and host_el.text:
                raw_text = host_el.get_text(strip=True)
                return _clean_host_name(raw_text)
        return None

    def _find_host_by_index(link_el, idx):
        """Caută numele hostului după index"""
        selectors = [
            f".movie_version[data-id='{idx}'] .version-host",
            f"li[data-id='{idx}'] .version-host",
            f".server_version[data-id='{idx}'] .version-host",
        ]

        for selector in selectors:
            host_el = link_el.find_previous_sibling(selector) or link_el.find_next_sibling(selector)
            if not host_el:
                host_el = link_el.get_parent().select_one(selector) if link_el.get_parent() else None

            if host_el and host_el.text:
                raw_text = host_el.get_text(strip=True)
                return _clean_host_name(raw_text)
        return None

    def _find_host_in_container(link_el):
        """Caută numele hostului în container-ul apropiat"""
        container = link_el.find_parent('li') or link_el.find_parent('div', class_=re.compile(r'version|server|link'))

        if container:
            host_elements = container.select('.version-host, .server-name, .host-name')
            for host_el in host_elements:
                if host_el.text:
                    raw_text = host_el.get_text(strip=True)
                    cleaned = _clean_host_name(raw_text)
                    if cleaned:
                        return cleaned
        return None

    def _extract_quality(link_el):
        """Extrage informații despre calitate din element sau din părinți"""
        # Caută în textul link-ului
        link_text = link_el.get_text(strip=True)
        if re.search(r'\b(4k|uhd|2160p)\b', link_text, re.I):
            return "4K"
        elif re.search(r'\b(1080p|full hd|fhd)\b', link_text, re.I):
            return "1080p"
        elif re.search(r'\b(720p|hd)\b', link_text, re.I):
            return "720p"
        elif re.search(r'\b(480p|sd)\b', link_text, re.I):
            return "480p"

        # Caută în părinți
        for parent in link_el.parents:
            parent_text = parent.get_text(strip=True)
            if re.search(r'\b(4k|uhd|2160p)\b', parent_text, re.I):
                return "4K"
            elif re.search(r'\b(1080p|full hd|fhd)\b', parent_text, re.I):
                return "1080p"
            elif re.search(r'\b(720p|hd)\b', parent_text, re.I):
                return "720p"
            elif re.search(r'\b(480p|sd)\b', parent_text, re.I):
                return "480p"

            # Caută în clase
            class_attr = parent.get('class', [])
            for cls in class_attr:
                if '4k' in cls.lower() or 'uhd' in cls.lower():
                    return "4K"
                elif '1080' in cls.lower():
                    return "1080p"
                elif '720' in cls.lower():
                    return "720p"
                elif '480' in cls.lower():
                    return "480p"

        return "HD"

    def _clean_host_name(raw_text):
        """Curăță și formatează numele hostului"""
        if not raw_text:
            return None

        cleaned = raw_text.strip()
        cleaned = re.sub(r'[^a-zA-Z0-9\s]', ' ', cleaned)
        cleaned = re.sub(r'\s+', ' ', cleaned)

        # Elimină cuvinte comune
        unwanted_terms = ['server', 'link', 'version', 'quality', 'hd', 'full', 'movie', 'tv', 'watch']
        words = [word for word in cleaned.split() if word.lower() not in unwanted_terms]

        cleaned = ' '.join(words).strip()

        if (cleaned and
            len(cleaned) >= 2 and
            len(cleaned) <= 30 and
            not cleaned.isdigit() and
            cleaned.lower() != 'unknown'):
            return cleaned.lower()

        return None

    # ---------- session setup ----------
    session = requests.Session()
    session.headers.update(
        {
            "User-Agent": "Mozilla/5.0 (X11; Linux x86_64; rv:128.0) Gecko/20100101 Firefox/128.0",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.5",
            "DNT": "1",
            "Connection": "keep-alive",
        }
    )

    # ---------- get internal ID ----------
    try:
        internal_id = get_internal_id(imdb_id, session, base_url)
    except Exception as e:
        raise RuntimeError(f"Failed to get internal ID: {e}")

    # ---------- build main page URL ----------
    film_type = "tv" if is_tv else "movie"
    page_url = f"{base_url}/{film_type}/{internal_id}"

    # ---------- fetch main page ----------
    resp = session.get(page_url, timeout=timeout)
    resp.raise_for_status()
    html = resp.text
    soup = BeautifulSoup(html, "html.parser")

    # Actualizează page_url cu URL-ul final (după redirecționări)
    page_url = resp.url

    # ---------- handle TV episodes ----------
    if is_tv and season and episode:
        try:
            episode_url = get_episode_page_url(soup, season, episode, base_url)
            resp = session.get(episode_url, timeout=timeout)
            resp.raise_for_status()
            html = resp.text
            soup = BeautifulSoup(html, "html.parser")
            page_url = resp.url  # Actualizează page_url pentru referer
        except Exception as e:
            raise RuntimeError(f"Failed to navigate to episode: {e}")

    # ---------- extract encrypted blob ----------
    el = None
    selectors = [
        "div#user-data",
        "span#user-data",
        "#user-data",
        '[id="user-data"]'
    ]

    for selector in selectors:
        el = soup.select_one(selector)
        if el and el.has_attr("v"):
            break

    if not el or not el.has_attr("v"):
        debug_info = {
            'page_title': soup.title.string if soup.title else 'No title',
            'has_user_data': bool(soup.find(id='user-data')),
            'has_propper_links': len(soup.select('.propper-link[link_version]')) > 0,
            'final_url': page_url
        }

        # Încearcă pagina de embed ca fallback
        try:
            if is_tv:
                embed_url = f"{base_url}/embed/tv/{internal_id}?season={season}&episode={episode}"
            else:
                embed_url = f"{base_url}/embed/movie/{internal_id}"

            embed_resp = session.get(embed_url, timeout=timeout)
            embed_resp.raise_for_status()
            embed_html = embed_resp.text
            embed_soup = BeautifulSoup(embed_html, "html.parser")

            for selector in selectors:
                el = embed_soup.select_one(selector)
                if el and el.has_attr("v"):
                    soup = embed_soup
                    html = embed_html
                    page_url = embed_url
                    break

        except Exception as embed_error:
            debug_info['embed_fallback_error'] = str(embed_error)

        if not el or not el.has_attr("v"):
            raise ValueError(f"Nu am găsit #user-data[v] în pagină. Debug: {debug_info}")

    encrypted_string = el["v"]
    keys = decrypt_keys(encrypted_string)
    if not keys:
        raise ValueError("Decriptare nereușită sau fără chei.")

    # ---------- extract ALL server information ----------
    servers_info = []
    for link_el in soup.select(".propper-link[link_version]"):
        link_version = link_el.get("link_version")
        if link_version and link_version.isdigit():
            idx = int(link_version)
            if idx < len(keys):
                # Extrage numele hostului și calitatea
                host_name, quality = extract_host_info(link_el, idx)

                servers_info.append({
                    "index": idx,
                    "host": host_name,
                    "quality": quality,
                    "key": keys[idx],
                    "element_html": str(link_el)[:150]  # Pentru debug
                })

    # ---------- resolve keys to actual URLs ----------
    results = []
    for server in servers_info:
        key = server["key"]
        try:
            result = resolve_key(session, base_url, key, page_url, max_retries)
            result["host_display"] = server["host"]
            result["quality"] = server["quality"]
            result["index"] = server["index"]
            results.append(result)
        except Exception as e:
            results.append({
                "host_display": server["host"],
                "quality": server["quality"],
                "index": server["index"],
                "key": key,
                "error": str(e)
            })

    return results


# Funcție pentru Kodi care returnează sursele în formatul așteptat
def get_kodi_sources(imdb_id, media_type, season=None, episode=None, max_retries=3):
    """
    Funcție optimizată pentru Kodi care returnează sursele în formatul așteptat.

    Args:
        imdb_id: IMDb ID-ul conținutului
        media_type: 'movie' sau 'tv'
        season: Sezonul (doar pentru TV)
        episode: Episodul (doar pentru TV)
        max_retries: Numărul de încercări pentru fiecare link

    Returns:
        Lista de surse în format Kodi
    """
    is_tv = media_type == 'tv'

    try:
        sources = get_primewire_sources(
            imdb_id=imdb_id,
            is_tv=is_tv,
            season=season or 1,
            episode=episode or 1,
            max_retries=max_retries
        )

        # Formatează sursele pentru Kodi
        kodi_sources = []
        for source in sources:
            if 'error' not in source and 'link' in source:
                display_name = source.get('host_display') or source.get('host', 'Unknown')

                kodi_sources.append({
                    'name': display_name,
                    'url': source['link'],
                    'quality': source.get('quality', 'HD'),
                    'info': {
                        'type': 'video',
                        'via': source.get('via', 'direct')
                    }
                })

        return kodi_sources

    except Exception as e:
        # Loghează eroarea pentru Kodi
        import xbmc
        xbmc.log(f"PrimeWire Resolver Error: {e}", xbmc.LOGERROR)
        return []


# Exemplu de utilizare cu afișare completă
if __name__ == "__main__":
    test_cases = [
        {"imdb_id": "tt32376165", "is_tv": False},
    ]

    for test in test_cases:
        print(f"\n🔍 Testing: {test}")
        try:
            sources = get_primewire_sources(**test, max_retries=3)

            print(f"\n📺 TOATE SURSELE VIDEO ({len(sources)}):")
            successful = 0
            failed = 0

            # Grupează sursele după host pentru analiză
            host_count = {}
            for source in sources:
                host = source.get('host_display', 'unknown')
                host_count[host] = host_count.get(host, 0) + 1

            print(f"\n📊 DISTRIBUȚIE SERVERE:")
            for host, count in sorted(host_count.items()):
                print(f"   {host}: {count} linkuri")

            # Afișează toate linkurile
            print(f"\n🔗 LISTA COMPLETĂ LINKURI:")
            for i, source in enumerate(sources, 1):
                if "error" in source:
                    failed += 1
                    print(f"❌ #{i:2d} - {source['index']:2d} | {source['host_display']:15} | {source['quality']:6} | {source['key']} → ERROR: {source['error']}")
                else:
                    successful += 1
                    print(f"✅ #{i:2d} - {source['index']:2d} | {source['host_display']:15} | {source['quality']:6} | {source['key']} | {source['via']}")
                    if source.get('link'):
                        print(f"      🔗 {source['link']}")

            print(f"\n📊 REZUMAT COMPLET:")
            print(f"✅ Linkuri funcționale: {successful}")
            print(f"❌ Linkuri eșuate: {failed}")
            print(f"🔗 Total linkuri: {len(sources)}")
            print(f"🏷️  Servere unice: {len(host_count)}")
            print(f"🔄 Retry-uri configurate: 3")
            print(f"🌐 URL pagină: {test.get('imdb_id', 'N/A')}")

        except Exception as e:
            print(f"💥 Eroare: {e}")
            import traceback
            traceback.print_exc()

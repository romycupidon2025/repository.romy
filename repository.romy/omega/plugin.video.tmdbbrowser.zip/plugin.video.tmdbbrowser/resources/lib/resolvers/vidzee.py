# -*- coding: utf-8 -*-
import json
import urllib.parse
import requests

HEADERS = {
    'User-Agent': 'Mozilla/5.0',
    'Referer': 'https://core.vidzee.wtf/'
}

def _fetch_data(tmdb_id, media_type, season=None, episode=None, scraper_api_key=None):
    if not tmdb_id or media_type not in ['movie', 'tv']:
        return []

    base_url = f"https://player.vidzee.wtf/api/server?id={tmdb_id}&sr=4"
    if media_type == 'tv':
        if not season or not episode:
            return []
        base_url += f"&ss={season}&ep={episode}"

    if scraper_api_key:
        final_url = f"https://api.scraperapi.com/?api_key={scraper_api_key}&url={urllib.parse.quote_plus(base_url)}"
        headers = {}
        timeout = 25
    else:
        final_url = base_url
        headers = HEADERS
        timeout = 15

    try:
        response = requests.get(final_url, headers=headers, timeout=timeout)
        data = response.json()
        return data
    except Exception as e:
        print(f"[VidZee] Eroare la request: {e}")
        return {}

def get_vidzee_movie_sources(tmdb_id, scraper_api_key=None):
    data = _fetch_data(tmdb_id, "movie", scraper_api_key=scraper_api_key)
    return _parse_sources(data)

def get_vidzee_tv_sources(tmdb_id, season, episode, scraper_api_key=None):
    data = _fetch_data(tmdb_id, "tv", season, episode, scraper_api_key)
    return _parse_sources(data)

def _parse_sources(data):
    stream_list = []

    sources = data.get("url", []) if isinstance(data.get("url"), list) else []
    if isinstance(data.get("link"), str):
        sources.append(data)

    for src in sources:
        link = src.get('link')
        if not link:
            continue

        title = src.get('name') or src.get('type') or 'VidZee'
        quality = f"{title}p" if title.isdigit() else title

        stream = {
            'title': f"VidZee - {quality}",
            'url': link,
            'label': f"[1080p] {quality}",
            'quality': quality,
            'provider': 'VidZee',
            'direct': True,
            'headers': {'Referer': 'https://core.vidzee.wtf/'}
        }


        # ✅ Subtitrări dacă există
        if 'subtitle' in src and isinstance(src['subtitle'], str) and src['subtitle'].endswith('.vtt'):
            stream['subtitles'] = [src['subtitle']]

        stream_list.append(stream)

    return stream_list

def get_sources(tmdb_id, media_type, season=None, episode=None, scraper_api_key=None):
    if media_type == "movie":
        return get_vidzee_movie_sources(tmdb_id, scraper_api_key)
    elif media_type == "tv":
        return get_vidzee_tv_sources(tmdb_id, season, episode, scraper_api_key)
    else:
        return []


import requests
import re
import xbmc

def get_vidsrc_sources(tmdb_id):
    url = f"https://vidsrc.su/embed/movie/{tmdb_id}"
    return _extract_sources(url, "film")

def get_vidsrc_tv_sources(tmdb_id, season, episode):
    url = f"https://vidsrc.su/embed/tv/{tmdb_id}/{season}/{episode}"
    return _extract_sources(url, "serial")

def _extract_sources(url, tip):
    headers = {
        "User-Agent": "Mozilla/5.0 (X11; Linux x86_64)",
        "Referer": "https://vidsrc.su/"
    }

    try:
        response = requests.get(url, headers=headers, timeout=30)
        html = response.text

        match = re.search(r'const\s+fixedServers\s*=\s*(\[.*?\]);', html, re.DOTALL)
        if not match:
            xbmc.log(f"[vidsrc_su] Nu s-a găsit array-ul fixedServers în HTML pentru {tip}.", xbmc.LOGERROR)
            return []

        raw_array = match.group(1)

        server_matches = re.findall(
            r"\{\s*label:\s*'([^']+)'\s*,\s*url:\s*'([^']+)'\s*\}",
            raw_array
        )

        sources = [{"label": label, "url": url} for label, url in server_matches]

        for source in sources:
            xbmc.log(f"[vidsrc_su] Sursă: {source['label']} → {source['url']}", xbmc.LOGINFO)

        xbmc.log(f"[vidsrc_su] S-au extras {len(sources)} surse pentru {tip}.", xbmc.LOGINFO)
        return sources

    except Exception as e:
        xbmc.log(f"[vidsrc_su] Eroare la extragerea surselor pentru {tip}: {e}", xbmc.LOGERROR)
        return []

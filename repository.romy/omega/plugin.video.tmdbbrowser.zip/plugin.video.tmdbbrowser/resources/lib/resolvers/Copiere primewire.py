#primewire.py
import requests
from bs4 import BeautifulSoup
from base64 import b64decode
from Cryptodome.Cipher import Blowfish
import re

def get_primewire_sources(imdb_id, is_tv=False, season=1, episode=1):
    BASE_URL = "https://www.primewire.mov"

    class BlowfishDecryptor:
        def __init__(self, key: str):
            self.key = key.encode("utf-8")
            self.cipher = Blowfish.new(self.key, Blowfish.MODE_ECB)

        def decrypt(self, data: str) -> str:
            decoded_data = b64decode(data)
            decrypted_data = self.cipher.decrypt(decoded_data)
            decrypted_data = decrypted_data.rstrip(b"\x00")
            return decrypted_data.decode("utf-8", errors="ignore")

    def l_function(encrypted_string: str):
        key = encrypted_string[-10:]
        encrypted = encrypted_string[:-10]
        decryptor = BlowfishDecryptor(key)
        decrypted = decryptor.decrypt(encrypted)
        return re.findall(r".{1,5}", decrypted)

    # Step 1: Get embed page
    if is_tv:
        embed_url = f"{BASE_URL}/embed/tv?imdb={imdb_id}&season={season}&episode={episode}"
    else:
        embed_url = f"{BASE_URL}/embed/movie?imdb={imdb_id}"

    headers = {
        "User-Agent": "Mozilla/5.0",
        "Referer": BASE_URL,
    }
    response = requests.get(embed_url, headers=headers)
    soup = BeautifulSoup(response.text, "html.parser")

    # Step 2: Extract encrypted string
    span = soup.find("span", {"id": "user-data"})
    if not span or not span.has_attr("v"):
        raise ValueError("Encrypted video data not found!")
    encrypted_string = span["v"]

    # Step 3: Decrypt host_keys
    host_keys = l_function(encrypted_string)

    # Step 4: Get final video links
    video_links = []
    for host_key in host_keys:
        go_url = f"{BASE_URL}/links/go/{host_key}?embed=true"
        try:
            r = requests.get(go_url, headers=headers)
            data = r.json()
            video_links.append({"host": data.get("host"), "link": data.get("link")})
        except Exception as e:
            print(f"Eroare la {host_key}: {e}")

    return video_links

# Exemplu de utilizare:
if __name__ == "__main__":
    imdb_id = "tt2661044"
    is_tv = True
    season = 1
    episode = 1
    sources = get_primewire_sources(imdb_id, is_tv=is_tv, season=season, episode=episode)

    print("\nSurse video extrase:")
    for idx, item in enumerate(sources, 1):
        print(f"#{idx} - {item['host']}: {item['link']}")

import requests
import base64
import json
import re
import xbmc
import xbmcgui
import xbmcplugin

# Definim funcția pentru crearea unui obiect de eroare
def create_error_object(error_message):
    return {
        "provider": "EmbedSU",
        "ERROR": [{
            "error": "ERROR",
            "what_happened": error_message,
            "report_issue": 'https://github.com/Inside4ndroid/TMDB-Embed-API/issues'
        }]
    }

# Funcția de decodare a unui string base64
def string_atob(input_str):
    padding = "=" * (4 - len(input_str) % 4)
    input_str += padding
    return base64.b64decode(input_str).decode('utf-8')

# Funcția principală pentru a obține sursele din EmbedSU
def get_embed_su(imdb_id, s=None, e=None):
    DOMAIN = "https://embed.su"
    headers = {
        'User-Agent': "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
        'Referer': DOMAIN,
        'Origin': DOMAIN,
    }

    try:
        if s and e:
            url_search = f"{DOMAIN}/embed/tv/{imdb_id}/{s}/{e}"
        else:
            url_search = f"{DOMAIN}/embed/movie/{imdb_id}"

        html_search = requests.get(url_search, headers=headers)

        if html_search.status_code != 200:
            return {"sources": [create_error_object(f"Failed to fetch initial page: HTTP {html_search.status_code}")]}

        text_search = html_search.text
        hash_encode_match = re.search(r"JSON\.parse\(atob\(\`([^\`]+)\`", text_search)
        hash_encode = hash_encode_match.group(1) if hash_encode_match else ""

        if not hash_encode:
            return {"sources": [create_error_object("No encoded hash found in initial page")]}

        try:
            hash_decode = json.loads(string_atob(hash_encode))
        except Exception as e:
            return {"sources": [create_error_object(f"Failed to decode initial hash: {e.message}")]}

        m_encrypt = hash_decode.get('hash')
        if not m_encrypt:
            return {"sources": [create_error_object("No encrypted hash found in decoded data")]}

        try:
            first_decode = string_atob(m_encrypt).split(".")
            first_decode = [item[::-1] for item in first_decode]
        except Exception as e:
            return {"sources": [create_error_object(f"Failed to decode first layer: {e.message}")]}

        try:
            second_decode = json.loads(string_atob(''.join(first_decode)[::-1]))
        except Exception as e:
            return {"sources": [create_error_object(f"Failed to decode second layer: {e.message}")]}

        if not second_decode:
            return {"sources": [create_error_object("No valid sources found after decoding")]}

        sources = []
        for item in second_decode:
            try:
                url_direct = f"{DOMAIN}/api/e/{item['hash']}"
                data_direct = requests.get(url_direct, headers=headers).json()

                if not data_direct or 'source' not in data_direct:
                    continue

                tracks = [
                    {"url": sub['file'], "lang": sub['label'].split('-')[0].strip() if sub['label'] else 'en'}
                    for sub in data_direct.get('subtitles', [])
                    if sub.get('file')
                ]

                request_direct_size = requests.get(data_direct['source'], headers=headers)
                if request_direct_size.status_code != 200:
                    continue

                parse_request = request_direct_size.text
                pattern_size = [item for item in parse_request.split('\n') if '/proxy/' in item]

                direct_quality = [
                    {
                        "file": f"{DOMAIN}{item.replace('.png', '.m3u8')}",
                        "type": "hls",
                        "quality": f"{get_size_quality(item)}p",
                        "lang": "en"
                    } for item in pattern_size
                ]

                if direct_quality:
                    sources.append({
                        "provider": "EmbedSu",
                        "files": direct_quality,
                        "subtitles": tracks,
                        "headers": headers
                    })

            except Exception as e:
                continue

        if not sources:
            return {"sources": [create_error_object("No valid sources found after processing all items")]}

        return {"sources": sources}

    except Exception as e:
        return {"sources": [create_error_object(f"Unexpected error: {e}")]}

# Funcția pentru a obține calitatea fișierului video
def get_size_quality(url):
    try:
        parts = url.split('/')
        base64_part = parts[-2]
        decoded_part = base64.b64decode(base64_part).decode('utf-8')
        return int(decoded_part) if decoded_part else 1080
    except Exception as e:
        return 720

# Funcția pentru a face request GET
def requestGet(url, headers):
    try:
        response = requests.get(url, headers=headers)
        response.raise_for_status()  # Ridică o excepție pentru statusuri non-200
        return response.json()
    except requests.exceptions.RequestException as e:
        xbmc.log(f"Error in GET request: {e}", level=xbmc.LOGERROR)
        return None

# Exemplu de utilizare în Kodi
def fetch_sources(imdb_id, s=None, e=None):
    result = get_embed_su(imdb_id, s, e)
    if "sources" in result:
        for source in result["sources"]:
            # Poți procesa sursele în Kodi, folosind resolveurl sau alte metode pentru a reda
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=source['files'][0]['file'], listitem=xbmcgui.ListItem(label="Stream"), isFolder=False)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

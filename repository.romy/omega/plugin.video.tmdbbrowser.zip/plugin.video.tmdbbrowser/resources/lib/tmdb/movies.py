### plugin.video.tmdbbrowser/resources/lib/tmdb/movies.py
from .api import tmdb_request

def get_popular_movies(page=1):
    return tmdb_request('movie/popular', {'page': page})

def get_trending_movies(page=1):
    return tmdb_request('trending/movie/week', {'page': page})

def get_movie_genres():
    return tmdb_request('genre/movie/list')

def get_movies_by_genre(genre_id, page=1):
    return tmdb_request('discover/movie', {'with_genres': genre_id, 'page': page})

def get_movies_by_year(year, page=1):
    return tmdb_request('discover/movie', {'primary_release_year': year, 'page': page})

def get_movie_providers():
    return tmdb_request('watch/providers/movie')

def get_movies_by_provider(provider_id, page=1):
    return tmdb_request('discover/movie', {'with_watch_providers': provider_id, 'page': page})

def search_movies(query):
    return tmdb_request('search/movie', {'query': query})

def get_movie_details(tmdb_id):
    return tmdb_request(f'movie/{tmdb_id}', {
        'append_to_response': 'credits,videos,external_ids,images'
    })

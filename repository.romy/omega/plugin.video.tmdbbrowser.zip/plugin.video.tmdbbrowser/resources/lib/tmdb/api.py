### plugin.video.tmdbbrowser/resources/lib/tmdb/api.py
import xbmcaddon
import xbmc
import requests

addon = xbmcaddon.Addon()
API_KEY = addon.getSetting('api_key')
region = addon.getSetting('provider_region')
REGION_VALUES = ['RO', 'US', 'GB', 'DE', 'FR', 'All']
LANGUAGE = addon.getSetting('language') or 'ro'

BASE_URL = 'https://api.themoviedb.org/3/'

def tmdb_request(endpoint, params={}):
    region_index = int(addon.getSetting('provider_region') or 0)
    region = REGION_VALUES[region_index]

    params.update({
        'api_key': API_KEY,
        'language': LANGUAGE
    })

    if region != 'All' and 'watch_region' not in params:
        params['watch_region'] = region
        xbmc.log(f"[TMDb Addon] watch_region set to: {region}", xbmc.LOGINFO)

    try:
        url = BASE_URL + endpoint
        xbmc.log(f'[TMDb Request] URL: {url} | Params: {params}', xbmc.LOGINFO)
        response = requests.get(url, params=params)
        if response.ok:
            return response.json()
        else:
            xbmc.log(f'[TMDb Error] HTTP {response.status_code}: {response.text}', xbmc.LOGERROR)
            return {}
    except Exception as e:
        xbmc.log(f'[TMDb Exception] {e}', xbmc.LOGERROR)
        return {}


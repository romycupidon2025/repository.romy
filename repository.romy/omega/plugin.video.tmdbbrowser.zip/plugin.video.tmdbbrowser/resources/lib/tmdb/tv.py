### plugin.video.tmdbbrowser/resources/lib/tmdb/tv.py
from .api import tmdb_request

def get_popular_tv(page=1):
    return tmdb_request('tv/popular', {'page': page})

def get_trending_tv(page=1):
    return tmdb_request('trending/tv/week', {'page': page})

def get_tv_genres():
    return tmdb_request('genre/tv/list')

def get_tv_by_genre(genre_id, page=1):
    return tmdb_request('discover/tv', {'with_genres': genre_id, 'page': page})

def get_tv_by_year(year, page=1):
    return tmdb_request('discover/tv', {'first_air_date_year': year, 'page': page})

def get_tv_providers():
    return tmdb_request('watch/providers/tv')

def get_tv_by_provider(provider_id, page=1):
    return tmdb_request('discover/tv', {'with_watch_providers': provider_id, 'page': page})

def search_tvshows(query):
    return tmdb_request('search/tv', {'query': query})

def get_tv_details(tv_id):
    return tmdb_request(f'tv/{tv_id}')

def get_season(tv_id, season_number):
    return tmdb_request(f'tv/{tv_id}/season/{season_number}')

def get_tv_details(tv_id):
    return tmdb_request(f'tv/{tv_id}', {'append_to_response': 'credits,images,external_ids'})

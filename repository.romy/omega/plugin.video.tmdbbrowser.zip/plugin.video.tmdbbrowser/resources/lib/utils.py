import os
import xbmc
import xbmcgui
import xbmcaddon
from .tmdb.api import tmdb_request

addon = xbmcaddon.Addon()
IMG_BASE = 'https://image.tmdb.org/t/p/w500'
FANART_BASE = 'https://image.tmdb.org/t/p/original'
ICON_PATH = os.path.join(addon.getAddonInfo('path'), 'resources', 'media', 'icons')
LANGUAGE = addon.getSetting('language') or 'ro'
GENRE_ICON_MAP = {
    "aventuri": ["Acţiune & Aventuri", "Acțiune & Aventuri", "Action & Adventure", "Aventuri", "Adventure"],
    "razboi": ["Război", "Razboi", "Război & Politică", "Razboi & Politica", "War & Politics", "War"],
    "sf": ["SF", "Sci-Fi", "SF & Fantasy", "SF și Fantezie", "Sci-Fi & Fantasy", "Science Fiction"],
    "filmtv": ["Film TV", "TV Movie"],
    "animatie": ["Animație", "Animatie", "Animation"],
    "stiri": ["Știri", "Stiri", "News"],
    "soap": ["Telenovelă", "Telenovela", "Soap"],
    "reality": ["Reality"],
    "copii": ["Copii", "Kids"],
    "romantic": ["Romantic", "Romance"],
    "mister": ["Mister", "Mystery"],
    "crima": ["Crimă", "Crima", "Crime"],
    "actiune": ["Acțiune", "Actiune", "Action"],
    "drama": ["Dramă", "Drama"],
    "fantezie": ["Fantezie", "Fantasy"],
    "comedie": ["Comedie", "Comedy"],
    "western": ["Western"],
    "horror": ["Horror"],
    "documentar": ["Documentar", "Documentary"],
    "muzica": ["Muzical", "Music"],
    "istoric": ["Istoric", "History"],
    "familie": ["Familie", "Family"],
    "thriller": ["Thriller"],
    "talkshow": ["Talk", "Talkshow"]
}

#FILME
def build_item(item):
    title = item.get('title') or item.get('name') or 'Fără titlu'
    year = (item.get('release_date') or '')[:4]
    genres_list = [g.get('name') for g in item.get('genres', [])]
    genres = ' / '.join(genres_list)
    duration = item.get('runtime') or 0
    rating = item.get('vote_average') or 0
    votes = int(item.get('vote_count') or 0)
    premiered = item.get('release_date', '')
    cast = item.get('credits', {}).get('cast', [])

    # Descriere cu fallback la engleză
    plot = item.get('overview', '')
    if not plot and LANGUAGE != 'en':
        fallback = tmdb_request(f"movie/{item['id']}", {'language': 'en'})
        plot = fallback.get('overview', '')

    label = f"{title} ({year})" if year else title

    li = xbmcgui.ListItem(label=label)
    li.setLabel2(genres)

    li.setArt({
        'thumb': IMG_BASE + (item.get('poster_path') or ''),
        'icon': IMG_BASE + (item.get('poster_path') or ''),
        'fanart': FANART_BASE + (item.get('backdrop_path') or '')
    })
    # Metadata Kodi 21+
    info = li.getVideoInfoTag()
    info.setTitle(title)
    if year:
        info.setYear(int(year))
    if genres_list:
        info.setGenres(genres_list)
    info.setDuration(duration)
    info.setPlot(plot)
    info.setPlotOutline(plot)
    info.setRating(rating)
    info.setVotes(votes)
    info.setPremiered(premiered)
    info.setMediaType('movie')

    # Cast folosind xbmc.Actor()
    if cast:
        cast_list = []
        for a in cast[:5]:
            name = a.get('name', '').strip()
            if not name:
                continue
            role = a.get('character', '')
            thumb = IMG_BASE + a['profile_path'] if a.get('profile_path') else ''
            actor = xbmc.Actor(name, role, -1, thumb)
            cast_list.append(actor)

        if cast_list:
            info.setCast(cast_list)
    return li

#SERIALE
def build_item_tvshow(item):
    title = item.get('name') or 'Fără titlu'
    year = (item.get('first_air_date') or '')[:4]
    genres_list = [g.get('name') for g in item.get('genres', [])]
    rating = item.get('vote_average') or 0
    votes = int(item.get('vote_count') or 0)
    premiered = item.get('first_air_date', '')
    status = item.get('status', '')
    cast = item.get('credits', {}).get('cast', [])
    seasons = item.get('number_of_seasons', 0)
    studios = [s.get('name') for s in item.get('production_companies', []) if s.get('name')]

    # Descriere cu fallback la engleză
    plot = item.get('overview', '')
    if not plot and LANGUAGE != 'en':
        fallback = tmdb_request(f"tv/{item['id']}", {'language': 'en'})
        plot = fallback.get('overview', '')

    label = f"{title} ({year})" if year else title

    li = xbmcgui.ListItem(label=label)
    li.setLabel2(' / '.join(genres_list))

    li.setArt({
        'thumb': IMG_BASE + (item.get('poster_path') or ''),
        'icon': IMG_BASE + (item.get('poster_path') or ''),
        'fanart': FANART_BASE + (item.get('backdrop_path') or '')
    })

    info = li.getVideoInfoTag()
    info.setTitle(title)
    info.setTvShowTitle(title)
    info.setTvShowStatus(status)
    if year:
        info.setYear(int(year))
    if genres_list:
        info.setGenres(genres_list)
    info.setPlot(plot)
    info.setPlotOutline(plot)
    info.setRating(rating)
    info.setVotes(votes)
    info.setPremiered(premiered)
    info.setMediaType('tvshow')

    # 🟢 Sezoane
    if seasons:
        info.addSeasons([(i + 1, f"Sezon {i + 1}") for i in range(seasons)])

    # 🟢 Tag-uri speciale
    tags = []
    if studios:
        tags += studios[:2]  # doar primele 2 companii pentru afișare
        if any(s.lower() in ['netflix', 'hbo', 'bbc', 'prime video'] for s in studios):
            tags.append('Original')

    if seasons == 1:
        tags.append('Miniserie')
    if rating >= 7.5:
        tags.append('Popular')

    if tags:
        info.setTags(tags)

    # 🟢 Actori
    if cast:
        cast_list = []
        for a in cast[:5]:
            name = a.get('name', '').strip()
            if not name:
                continue
            role = a.get('character', '')
            thumb = IMG_BASE + a['profile_path'] if a.get('profile_path') else ''
            actor = xbmc.Actor(name, role, -1, thumb)
            cast_list.append(actor)
        if cast_list:
            info.setCast(cast_list)

    return li

#ICONS
def get_icon_path(name):
    filename = f"{name.lower()}.png"
    path = os.path.join(ICON_PATH, filename)
    if os.path.exists(path):
        return path
    return ''  # sau un fallback: os.path.join(ICON_PATH, 'default.png')

#STANDARDIZARE NUME GENURI
def normalize_genre_name(name):
    normalized = (
        name.lower()
            .replace('ă', 'a')
            .replace('â', 'a')
            .replace('î', 'i')
            .replace('ș', 's')
            .replace('ş', 's')  # vechiul ș
            .replace('ț', 't')
            .replace('ţ', 't')  # vechiul ț
            .strip()
    )

    for icon, names in GENRE_ICON_MAP.items():
        if any(n.lower()
               .replace('ă', 'a').replace('â', 'a').replace('î', 'i')
               .replace('ș', 's').replace('ş', 's')
               .replace('ț', 't').replace('ţ', 't')
               .strip() == normalized for n in names):
            return icon

    # fallback: curățare completă
    return normalized.replace(' ', '').replace('-', '')

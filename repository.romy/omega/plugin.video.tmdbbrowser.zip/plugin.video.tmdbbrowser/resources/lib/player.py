import os
import sys
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import resolveurl
import threading
from resources.lib import subtitles
from resources.lib.tmdb import movies, tv
from resources.lib.resolvers import vidify, primewire, vidsrc, embedsu, vidzee, twoembed

addon = xbmcaddon.Addon()
handle = int(sys.argv[1])

profile_path = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
subs_path = os.path.join(profile_path, 'subs')
os.makedirs(subs_path, exist_ok=True)

def resolve_with_timeout(url, timeout=30):
    result = [None]

    def resolver():
        try:
            resolved_url = resolveurl.resolve(url)
            result[0] = resolved_url
        except Exception as e:
            xbmc.log(f"[resolve_with_timeout] Eroare: {e}", xbmc.LOGERROR)

    t = threading.Thread(target=resolver)
    t.start()
    t.join(timeout)
    if t.is_alive():
        xbmc.log(f"[resolve_with_timeout] ⏱️ Timeout de {timeout} secunde pentru URL: {url}", xbmc.LOGERROR)
        return None
    return result[0]

def threaded_resolver(target, args=(), result=None, index=0):
    def wrapper():
        try:
            data = target(*args)
            result[index] = data
        except Exception as e:
            xbmc.log(f"[Threaded Resolver] Eroare în {target.__name__}: {e}", xbmc.LOGERROR)
            result[index] = []
    t = threading.Thread(target=wrapper)
    t.start()
    return t


def play_movie(handle, tmdb_id):
    details = movies.get_movie_details(tmdb_id)
    imdb_id = details.get('imdb_id')
    title = details.get('title', 'Fără titlu')
    year = details.get('release_date', '')[:4]

    results = [None] * 6
    threads = []

    if addon.getSettingBool('use_vidify'):
        threads.append(threaded_resolver(vidify.get_vidify_movie_sources, (tmdb_id, imdb_id), results, 4))
    if addon.getSettingBool('use_primewire'):
        threads.append(threaded_resolver(primewire.get_primewire_sources, (imdb_id, False), results, 1))
    if addon.getSettingBool('use_vidsrc'):
        threads.append(threaded_resolver(vidsrc.get_vidsrc_sources, (tmdb_id,), results, 2))
    if addon.getSettingBool('use_embedsu'):
        threads.append(threaded_resolver(embedsu.get_embed_su, (imdb_id,), results, 3))
    if addon.getSettingBool('use_vidzee'):
        threads.append(threaded_resolver(vidzee.get_sources, (tmdb_id, "movie"), results, 0))
    if addon.getSettingBool('use_twoembed'):
        threads.append(threaded_resolver(twoembed.get_twoembed_sources, (tmdb_id,), results, 5))

    for t in threads:
        t.join()

    sources = []
    prefixes = ['[V]', '[P]', '[VS]', '[ES]', '[Z]', '[2E]']

    for i, (group, label_prefix) in enumerate(zip(results, prefixes)):
        if group:
            if label_prefix == '[ES]':
                for entry in group.get('sources', []):
                    if 'files' in entry:
                        for file in entry['files']:
                            file_url = file.get('file')
                            label = file.get('quality', 'Unknown')
                            sources.append({
                                'label': f"{label_prefix} {label}",
                                'url': file_url + "|User-Agent=Mozilla/5.0&Referer=https://embed.su/&Origin=https://embed.su/",
                                'direct': True
                            })
            else:
                for src in group:
                    label = src.get('label') or src.get('host') or src.get('url') or 'Unknown'
                    url = src.get('url') or src.get('link')
                    if label_prefix == '[P]':
                        direct = False
                    elif label_prefix == '[VS]' and url.endswith('.m3u8'):
                        url += "|User-Agent=Mozilla/5.0&Referer=https://vidsrc.su/&Origin=https://vidsrc.su/"
                        direct = True
                    elif label_prefix == '[Z]' and 'vidzee.wtf' in url:
                        url += "|User-Agent=Mozilla/5.0&Referer=https://core.vidzee.wtf/&Origin=https://core.vidzee.wtf/"
                        direct = True
                    elif label_prefix == '[2E]':
                        #url += "|User-Agent=Mozilla/5.0&Referer=https://www.2embed.cc/&Origin=https://www.2embed.cc/"
                        url += "|User-Agent=Mozilla/5.0&Referer=https://player4u.xyz/embed"
                        direct = False
                    else:
                        direct = True
                    sources.append({'label': f"{label_prefix} {label}", 'url': url, 'direct': direct})

    if not sources:
        xbmcgui.Dialog().notification('TMDb Browser', 'Nicio sursă video găsită.', xbmcgui.NOTIFICATION_ERROR)
        return

    index = xbmcgui.Dialog().select('Alege o sursă video', [s['label'] for s in sources])
    if index == -1:
        xbmcgui.Dialog().notification("Informație", "Nicio sursă selectată.", xbmcgui.NOTIFICATION_INFO)
        return

    selected = sources[index]
    url = selected['url']
    is_direct = selected['direct']

    li = xbmcgui.ListItem(path=url)
    li.setProperty('IsPlayable', 'true')

    if '.m3u8' in url:
        li.setMimeType("application/vnd.apple.mpegurl")
        li.setContentLookup(False)

    li.setInfo('video', {'title': title, 'year': year, 'imdbnumber': imdb_id or 'unknown'})

    # Subtitrări
    if imdb_id:
        subs = subtitles.search_subtitles(imdb_id)
        for sub in subs:
            sub_path = subtitles.download_subtitle(sub, subs_path)
            if sub_path:
                li.setSubtitles([sub_path])
                break

    if not is_direct:
        try:
            resolved = resolveurl.resolve(url)
            if resolved:
                li.setPath(resolved)
        except Exception as e:
            xbmc.log(f'[resolveurl] Eroare: {e}', xbmc.LOGERROR)
    xbmcplugin.setResolvedUrl(handle, True, li)


def play_tv_episode(handle, tv_id, season, episode):
    details = tv.get_tv_details(tv_id)
    imdb_id = details.get('external_ids', {}).get('imdb_id')
    show_title = details.get('name', 'Unknown').replace(' ', '.')
    episode_tag = f"{show_title}.S{season:02d}E{episode:02d}"

    results = [None] * 6
    threads = []

    if addon.getSettingBool('use_vidify'):
        threads.append(threaded_resolver(vidify.get_vidify_tv_episode_sources, (tv_id, imdb_id, season, episode), results, 4))
    if addon.getSettingBool('use_primewire'):
        threads.append(threaded_resolver(primewire.get_primewire_sources, (imdb_id, True, season, episode), results, 1))
    if addon.getSettingBool('use_vidsrc'):
        threads.append(threaded_resolver(vidsrc.get_vidsrc_tv_sources, (tv_id, season, episode), results, 2))
    if addon.getSettingBool('use_embedsu'):
        threads.append(threaded_resolver(embedsu.get_embed_su, (imdb_id, season, episode), results, 3))
    if addon.getSettingBool('use_vidzee'):
        threads.append(threaded_resolver(vidzee.get_sources, (tv_id, "tv", season, episode), results, 0))
    if addon.getSettingBool('use_twoembed'):
        threads.append(threaded_resolver(twoembed.get_twoembed_sources, (tv_id, season, episode), results, 5))

    for t in threads:
        t.join()

    sources = []
    prefixes = ['[V]', '[P]', '[VS]', '[ES]', '[Z]', '[2E]']

    for i, (group, label_prefix) in enumerate(zip(results, prefixes)):
        if group:
            if label_prefix == '[ES]':
                for entry in group.get('sources', []):
                    if 'files' in entry:
                        for file in entry['files']:
                            file_url = file.get('file')
                            label = file.get('quality', 'Unknown')
                            sources.append({
                                'label': f"{label_prefix} {label}",
                                'url': file_url + "|User-Agent=Mozilla/5.0&Referer=https://embed.su/&Origin=https://embed.su/",
                                'direct': True
                            })
            else:
                for src in group:
                    label = src.get('label') or src.get('host') or src.get('url') or 'Unknown'
                    url = src.get('url') or src.get('link')
                    if label_prefix == '[P]':
                        direct = False
                    elif label_prefix == '[VS]' and url.endswith('.m3u8'):
                        url += "|User-Agent=Mozilla/5.0&Referer=https://vidsrc.su/&Origin=https://vidsrc.su/"
                        direct = True
                    elif label_prefix == '[Z]' and 'vidzee.wtf' in url:
                        url += "|User-Agent=Mozilla/5.0&Referer=https://core.vidzee.wtf/&Origin=https://core.vidzee.wtf/"
                        direct = True
                    elif label_prefix == '[2E]':
                        url += "|User-Agent=Mozilla/5.0&Referer=https://uqloads.xyz&Origin=https://uqloads.xyz"
                        direct = False
                    else:
                        direct = True
                    sources.append({'label': f"{label_prefix} {label}", 'url': url, 'direct': direct})

    if not sources:
        xbmcgui.Dialog().notification('TMDb Browser', 'Nicio sursă video găsită.', xbmcgui.NOTIFICATION_ERROR)
        return

    index = xbmcgui.Dialog().select('Alege o sursă video', [s['label'] for s in sources])
    if index == -1:
        xbmcgui.Dialog().notification("Informație", "Nicio sursă selectată.", xbmcgui.NOTIFICATION_INFO)
        return

    selected = sources[index]
    url = selected['url']
    is_direct = selected['direct']

    li = xbmcgui.ListItem(path=url)
    li.setProperty('IsPlayable', 'true')

    if '.m3u8' in url:
        li.setMimeType("application/vnd.apple.mpegurl")
        li.setContentLookup(False)
        li.setProperty('inputstream', 'inputstream.adaptive')
        li.setProperty('inputstream.adaptive.manifest_type', 'hls')


    li.setInfo('video', {
        'title': episode_tag,
        'tvshowtitle': show_title,
        'season': season,
        'episode': episode,
        'imdbnumber': imdb_id or 'unknown'
    })

    # Subtitrări
    if imdb_id:
        subs = subtitles.search_subtitles(imdb_id, season=season, episode=episode)
        for sub in subs:
            sub_path = subtitles.download_subtitle(sub, subs_path)
            if sub_path:
                li.setSubtitles([sub_path])
                break

    if not is_direct:
        xbmc.log(f"[resolveurl] 🔄 Rezolv URL: {url}", xbmc.LOGINFO)
        try:
            #resolved = resolveurl.resolve(url)
            resolved = resolve_with_timeout(url, timeout=30)
            if resolved:
                xbmc.log(f"[resolveurl] ✅ URL rezolvat: {resolved}", xbmc.LOGINFO)
                li.setPath(resolved)
            else:
                xbmc.log(f"[resolveurl] ❌ Nicio rezolvare pentru: {url}", xbmc.LOGWARNING)
        except Exception as e:
            xbmc.log(f'[resolveurl] ❌ Eroare la rezolvare: {e}', xbmc.LOGERROR)

    xbmcplugin.setResolvedUrl(handle, True, li)

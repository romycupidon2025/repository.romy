### plugin.video.tmdbbrowser/resources/lib/menus/movies.py
import sys
import xbmc
import xbmcgui
import xbmcplugin
from datetime import datetime
from urllib.parse import urlencode, quote
from resources.lib.utils import build_item
from resources.lib.utils import get_icon_path, normalize_genre_name
from resources.lib.tmdb import movies as tmdb_movies

handle = int(sys.argv[1])

def menu():
    xbmcplugin.setPluginCategory(handle, 'Filme')

    li = xbmcgui.ListItem('Populare')
    li.setArt({'thumb': get_icon_path('popular'), 'icon': get_icon_path('popular')})
    xbmcplugin.addDirectoryItem(handle, f'{sys.argv[0]}?action=movies_popular', li, isFolder=True)

    li = xbmcgui.ListItem('Trending')
    li.setArt({'thumb': get_icon_path('trending'), 'icon': get_icon_path('trending')})
    xbmcplugin.addDirectoryItem(handle, f'{sys.argv[0]}?action=movies_trending', li, isFolder=True)

    li = xbmcgui.ListItem('Genuri')
    li.setArt({'thumb': get_icon_path('genres'), 'icon': get_icon_path('genres')})
    xbmcplugin.addDirectoryItem(handle, f'{sys.argv[0]}?action=movies_genres', li, isFolder=True)

    li = xbmcgui.ListItem('Ani')
    li.setArt({'thumb': get_icon_path('ani'), 'icon': get_icon_path('ani')})
    xbmcplugin.addDirectoryItem(handle, f'{sys.argv[0]}?action=movies_years', li, isFolder=True)

    li = xbmcgui.ListItem('Furnizori')
    li.setArt({'thumb': get_icon_path('furnizori'), 'icon': get_icon_path('furnizori')})
    xbmcplugin.addDirectoryItem(handle, f'{sys.argv[0]}?action=movies_providers', li, isFolder=True)

    li = xbmcgui.ListItem('Căutare')
    li.setArt({'thumb': get_icon_path('search'), 'icon': get_icon_path('search')})
    xbmcplugin.addDirectoryItem(handle, f'{sys.argv[0]}?action=movies_search', li, isFolder=False)

    xbmcplugin.endOfDirectory(handle)

def search():
    keyboard = xbmcgui.Dialog().input('Caută film TMDb')
    if not keyboard:
        return
    query = keyboard.strip()
    if not query:
        return

    xbmc.executebuiltin(f'Container.Update("{sys.argv[0]}?action=movies_search_results&query={quote(query)}")')

def search_results(query):
    results = tmdb_movies.search_movies(query)
    if not results or 'results' not in results or not results['results']:
        xbmcgui.Dialog().notification('TMDb Browser', 'Nicio potrivire găsită.', xbmcgui.NOTIFICATION_INFO)
        return

    xbmcplugin.setPluginCategory(handle, f'Rezultate: {query}')
    xbmcplugin.setContent(handle, 'movies')

    for item in results['results']:
        li = build_item(item)
        li.setProperty('tmdb_id', str(item['id']))
        li.setProperty('tmdbhelper.context.name', 'TMDb Helper')
        li.setProperty('IsPlayable', 'true')
        url = f'{sys.argv[0]}?action=play_movie&id={item["id"]}'
        xbmcplugin.addDirectoryItem(handle, url=url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(handle)

def show_popular(page=1):
    popular = tmdb_movies.get_popular_movies(page)

    if not popular or 'results' not in popular:
        xbmcgui.Dialog().notification('TMDb Browser', 'Eroare la extragerea filmelor populare.', xbmcgui.NOTIFICATION_ERROR)
        return

    handle = int(sys.argv[1])
    top10 = popular['results'][:10]

    for item in top10:
        details = tmdb_movies.get_movie_details(item['id'])  # cu append_to_response
        li = build_item(details)
        li.setProperty('IsPlayable', 'true')
        url = f'{sys.argv[0]}?action=play_movie&tmdb_id={item["id"]}'
        xbmcplugin.setContent(handle, 'movies')
        xbmcplugin.addDirectoryItem(handle, url=url, listitem=li, isFolder=False)

    # Adaugă buton pentru pagina următoare
    next_page = page + 1
    next_url = f"{sys.argv[0]}?{urlencode({'action': 'movies_popular', 'page': next_page})}"
    li = xbmcgui.ListItem(label=f'Pagina {next_page} →')
    xbmcplugin.addDirectoryItem(handle, url=next_url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(handle)

def show_trending(page=1):
    xbmc.log(f"[TMDb Addon] movies_trending | page={page}", xbmc.LOGINFO)
    trending = tmdb_movies.get_trending_movies(page)

    if not trending or 'results' not in trending:
        xbmcgui.Dialog().notification('TMDb Browser', 'Eroare la extragerea filmelor trending.', xbmcgui.NOTIFICATION_ERROR)
        return

    for item in trending['results']:
        details = tmdb_movies.get_movie_details(item['id'])
        li = build_item(details)
        li.setProperty('IsPlayable', 'true')
        url = f'{sys.argv[0]}?action=play_movie&tmdb_id={item["id"]}'
        xbmcplugin.setContent(handle, 'movies')
        xbmcplugin.addDirectoryItem(handle, url=url, listitem=li, isFolder=False)

    next_page = page + 1
    next_url = f"{sys.argv[0]}?{urlencode({'action': 'movies_trending', 'page': next_page})}"
    xbmcplugin.addDirectoryItem(handle, url=next_url, listitem=xbmcgui.ListItem(f'Pagina {next_page}'), isFolder=True)

    xbmcplugin.endOfDirectory(handle)

def show_genres():
    genres = tmdb_movies.get_movie_genres()
    if not genres or 'genres' not in genres:
        xbmcgui.Dialog().notification('TMDb Browser', 'Eroare la extragerea genurilor.', xbmcgui.NOTIFICATION_ERROR)
        return

    for genre in genres['genres']:
        genre_id = genre['id']
        genre_name = genre['name']
        icon_key = normalize_genre_name(genre_name)
        icon_path = get_icon_path(icon_key)

        url = f"{sys.argv[0]}?{urlencode({'action': 'movies_by_genre', 'genre_id': genre_id, 'genre_name': genre_name, 'page': 1})}"
        li = xbmcgui.ListItem(label=genre_name)
        li.setArt({'icon': icon_path, 'thumb': icon_path})
        xbmcplugin.addDirectoryItem(handle, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(handle)

def show_by_genre(genre_id, genre_name, page=1):
    xbmcplugin.setPluginCategory(handle, f'Gen: {genre_name}')
    data = tmdb_movies.get_movies_by_genre(genre_id, page)

    if not data or 'results' not in data:
        xbmcgui.Dialog().notification('TMDb Browser', f'Eroare la genul {genre_name}', xbmcgui.NOTIFICATION_ERROR)
        return

    for item in data['results']:
        details = tmdb_movies.get_movie_details(item['id'])
        li = build_item(details)
        li.setProperty('IsPlayable', 'true')
        url = f'{sys.argv[0]}?action=play_movie&id={item["id"]}'
        xbmcplugin.setContent(handle, 'movies')
        xbmcplugin.addDirectoryItem(handle, url=url, listitem=li, isFolder=False)

    next_page = page + 1
    next_url = f"{sys.argv[0]}?{urlencode({'action': 'movies_by_genre', 'genre_id': genre_id, 'genre_name': genre_name, 'page': next_page})}"
    xbmcplugin.addDirectoryItem(handle, url=next_url, listitem=xbmcgui.ListItem(f'Pagina {next_page}'), isFolder=True)

    xbmcplugin.endOfDirectory(handle)

def show_years():
    current_year = datetime.now().year
    icon_path = get_icon_path('ani')  # iconiță unică pentru toți anii

    for year in range(current_year, 1940, -1):
        url = f"{sys.argv[0]}?{urlencode({'action': 'movies_by_year', 'year': year, 'page': 1})}"
        li = xbmcgui.ListItem(str(year))
        li.setArt({'icon': icon_path, 'thumb': icon_path})
        xbmcplugin.addDirectoryItem(handle, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(handle)

def show_by_year(year, page=1):
    data = tmdb_movies.get_movies_by_year(year, page)
    if not data or 'results' not in data:
        xbmcgui.Dialog().notification('TMDb Browser', f'Eroare la anul {year}', xbmcgui.NOTIFICATION_ERROR)
        return
    for item in data['results']:
        details = tmdb_movies.get_movie_details(item['id'])
        li = build_item(details)
        li.setProperty('IsPlayable', 'true')
        url = f'{sys.argv[0]}?action=play_movie&id={item["id"]}'
        xbmcplugin.setContent(handle, 'movies')
        xbmcplugin.addDirectoryItem(handle, url=url, listitem=li, isFolder=False)

    next_page = page + 1
    next_url = f"{sys.argv[0]}?{urlencode({'action': 'movies_by_year', 'year': year, 'page': next_page})}"
    xbmcplugin.addDirectoryItem(handle, url=next_url, listitem=xbmcgui.ListItem(f'Pagina {next_page}'), isFolder=True)
    xbmcplugin.endOfDirectory(handle)

def show_providers():
    providers = tmdb_movies.get_movie_providers()
    if not providers or 'results' not in providers:
        xbmcgui.Dialog().notification('TMDb Browser', 'Eroare la extragerea furnizorilor.', xbmcgui.NOTIFICATION_ERROR)
        return

    for provider in providers['results']:
        logo_path = provider.get('logo_path', '')
        thumb = 'https://image.tmdb.org/t/p/w200' + logo_path if logo_path else ''

        li = xbmcgui.ListItem(label=provider['provider_name'])
        li.setArt({
            'thumb': thumb,
            'icon': thumb,
            'fanart': thumb
        })

        url = f"{sys.argv[0]}?{urlencode({'action': 'movies_by_provider', 'provider_id': provider['provider_id'], 'provider_name': provider['provider_name'], 'page': 1})}"
        xbmcplugin.addDirectoryItem(handle, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(handle)

def show_by_provider(provider_id, provider_name, page=1):
    xbmcplugin.setPluginCategory(handle, f'Furnizor: {provider_name}')
    data = tmdb_movies.get_movies_by_provider(provider_id, page)
    if not data or 'results' not in data:
        xbmcgui.Dialog().notification('TMDb Browser', f'Eroare la furnizorul {provider_name}', xbmcgui.NOTIFICATION_ERROR)
        return
    for item in data['results']:
        details = tmdb_movies.get_movie_details(item['id'])
        li = build_item(details)
        li.setProperty('IsPlayable', 'true')
        url = f'{sys.argv[0]}?action=play_movie&id={item["id"]}'
        xbmcplugin.setContent(handle, 'movies')
        xbmcplugin.addDirectoryItem(handle, url=url, listitem=li, isFolder=False)

    next_page = page + 1
    next_url = f"{sys.argv[0]}?{urlencode({'action': 'movies_by_provider', 'provider_id': provider_id, 'provider_name': provider_name, 'page': next_page})}"
    xbmcplugin.addDirectoryItem(handle, url=next_url, listitem=xbmcgui.ListItem(f'Pagina {next_page}'), isFolder=True)
    xbmcplugin.endOfDirectory(handle)

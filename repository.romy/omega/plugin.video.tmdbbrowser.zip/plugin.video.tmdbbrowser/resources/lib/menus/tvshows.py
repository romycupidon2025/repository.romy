### plugin.video.tmdbbrowser/resources/lib/menus/tvshows.py
import sys
import xbmc
import xbmcgui
import xbmcplugin
from datetime import datetime
from urllib.parse import urlencode
from resources.lib.tmdb import tv as tmdb_tv
from resources.lib.utils import get_icon_path, normalize_genre_name
from resources.lib.utils import build_item_tvshow

handle = int(sys.argv[1])

def menu():
    xbmcplugin.setPluginCategory(handle, 'Seriale')

    li = xbmcgui.ListItem('Populare')
    li.setArt({'thumb': get_icon_path('popular'), 'icon': get_icon_path('popular')})
    xbmcplugin.addDirectoryItem(handle, f'{sys.argv[0]}?action=tvshows_popular', li, isFolder=True)

    li = xbmcgui.ListItem('Trending')
    li.setArt({'thumb': get_icon_path('trending'), 'icon': get_icon_path('trending')})
    xbmcplugin.addDirectoryItem(handle, f'{sys.argv[0]}?action=tvshows_trending', li, isFolder=True)

    li = xbmcgui.ListItem('Genuri')
    li.setArt({'thumb': get_icon_path('genres'), 'icon': get_icon_path('genres')})
    xbmcplugin.addDirectoryItem(handle, f'{sys.argv[0]}?action=tvshows_genres', li, isFolder=True)

    li = xbmcgui.ListItem('Ani')
    li.setArt({'thumb': get_icon_path('ani'), 'icon': get_icon_path('ani')})
    xbmcplugin.addDirectoryItem(handle, f'{sys.argv[0]}?action=tvshows_years', li, isFolder=True)

    li = xbmcgui.ListItem('Furnizori')
    li.setArt({'thumb': get_icon_path('furnizori'), 'icon': get_icon_path('furnizori')})
    xbmcplugin.addDirectoryItem(handle, f'{sys.argv[0]}?action=tvshows_providers', li, isFolder=True)

    li = xbmcgui.ListItem('Căutare')
    li.setArt({'thumb': get_icon_path('search'), 'icon': get_icon_path('search')})
    xbmcplugin.addDirectoryItem(handle, f'{sys.argv[0]}?action=tvshows_search', li, isFolder=True)

    xbmcplugin.endOfDirectory(handle)

def search():
    keyboard = xbmcgui.Dialog().input('Caută serial TMDb')
    if not keyboard:
        return

    results = tmdb_tv.search_tvshows(keyboard)
    if not results or 'results' not in results:
        xbmcgui.Dialog().notification('TMDb Browser', 'Nicio potrivire găsită.', xbmcgui.NOTIFICATION_INFO)
        return

    for item in results['results']:
        li = build_item_tvshow(item)
        url = f'{sys.argv[0]}?action=tv_details&id={item["id"]}'
        xbmcplugin.setContent(handle, 'tvshows')
        xbmcplugin.addDirectoryItem(handle, url=url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(handle)

def show_popular(page=1):
    xbmc.log(f"[TMDb Addon] tvshows_popular | page={page}", xbmc.LOGINFO)
    popular = tmdb_tv.get_popular_tv(page)

    if not popular or 'results' not in popular:
        xbmcgui.Dialog().notification('TMDb Browser', 'Eroare la extragerea serialelor populare.', xbmcgui.NOTIFICATION_ERROR)
        return

    for item in popular['results']:
        details = tmdb_tv.get_tv_details(item['id'])  # adaugă această funcție dacă nu există
        li = build_item_tvshow(details)
        url = f'{sys.argv[0]}?action=tv_details&id={item["id"]}'
        xbmcplugin.setContent(handle, 'tvshows')
        xbmcplugin.addDirectoryItem(handle, url=url, listitem=li, isFolder=True)

    next_page = page + 1
    next_url = f"{sys.argv[0]}?{urlencode({'action': 'tvshows_popular', 'page': next_page})}"
    xbmcplugin.addDirectoryItem(handle, url=next_url, listitem=xbmcgui.ListItem(f'Pagina {next_page}'), isFolder=True)
    xbmcplugin.endOfDirectory(handle)

def show_trending(page=1):
    xbmc.log(f"[TMDb Addon] tvshows_trending | page={page}", xbmc.LOGINFO)
    trending = tmdb_tv.get_trending_tv(page)

    if not trending or 'results' not in trending:
        xbmcgui.Dialog().notification('TMDb Browser', 'Eroare la extragerea serialelor trending.', xbmcgui.NOTIFICATION_ERROR)
        return

    for item in trending['results']:
        details = tmdb_tv.get_tv_details(item['id'])
        li = build_item_tvshow(details)
        url = f'{sys.argv[0]}?action=tv_details&id={item["id"]}'
        xbmcplugin.setContent(handle, 'tvshows')
        xbmcplugin.addDirectoryItem(handle, url=url, listitem=li, isFolder=True)

    next_page = page + 1
    next_url = f"{sys.argv[0]}?{urlencode({'action': 'tvshows_trending', 'page': next_page})}"
    xbmcplugin.addDirectoryItem(handle, url=next_url, listitem=xbmcgui.ListItem(f'Pagina {next_page}'), isFolder=True)

    xbmcplugin.endOfDirectory(handle)

def show_genres():
    genres = tmdb_tv.get_tv_genres()
    if not genres or 'genres' not in genres:
        xbmcgui.Dialog().notification('TMDb Browser', 'Eroare la extragerea genurilor.', xbmcgui.NOTIFICATION_ERROR)
        return

    for genre in genres['genres']:
        genre_id = genre['id']
        genre_name = genre['name']
        icon_key = normalize_genre_name(genre_name)
        icon_path = get_icon_path(icon_key)

        url = f"{sys.argv[0]}?{urlencode({'action': 'tvshows_by_genre', 'genre_id': genre_id, 'genre_name': genre_name, 'page': 1})}"
        li = xbmcgui.ListItem(label=genre_name)
        li.setArt({'icon': icon_path, 'thumb': icon_path})
        xbmcplugin.addDirectoryItem(handle, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(handle)

def show_years():
    current_year = datetime.now().year
    icon_path = get_icon_path('ani')  # iconiță unică pentru toate intrările

    for year in range(current_year, 1940, -1):
        url = f"{sys.argv[0]}?{urlencode({'action': 'tvshows_by_year', 'year': year, 'page': 1})}"
        li = xbmcgui.ListItem(str(year))
        li.setArt({'icon': icon_path, 'thumb': icon_path})
        xbmcplugin.addDirectoryItem(handle, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(handle)

def show_by_year(year, page=1):
    data = tmdb_tv.get_tv_by_year(year, page)
    if not data or 'results' not in data:
        xbmcgui.Dialog().notification('TMDb Browser', f'Eroare la anul {year}', xbmcgui.NOTIFICATION_ERROR)
        return
    for item in data['results']:
        details = tmdb_tv.get_tv_details(item['id'])  # adaugă această funcție dacă nu există
        li = build_item_tvshow(details)
        url = f'{sys.argv[0]}?action=tv_details&id={item["id"]}'
        xbmcplugin.setContent(handle, 'tvshows')
        xbmcplugin.addDirectoryItem(handle, url=url, listitem=li, isFolder=True)
    next_page = page + 1
    next_url = f"{sys.argv[0]}?{urlencode({'action': 'tvshows_by_year', 'year': year, 'page': next_page})}"
    xbmcplugin.addDirectoryItem(handle, url=next_url, listitem=xbmcgui.ListItem(f'Pagina {next_page}'), isFolder=True)
    xbmcplugin.endOfDirectory(handle)

def show_providers():
    providers = tmdb_tv.get_tv_providers()
    if not providers or 'results' not in providers:
        xbmcgui.Dialog().notification('TMDb Browser', 'Eroare la extragerea furnizorilor.', xbmcgui.NOTIFICATION_ERROR)
        return

    for provider in providers['results']:
        logo_path = provider.get('logo_path', '')
        thumb = 'https://image.tmdb.org/t/p/w200' + logo_path if logo_path else ''

        li = xbmcgui.ListItem(label=provider['provider_name'])
        li.setArt({
            'thumb': thumb,
            'icon': thumb,
            'fanart': thumb
        })

        url = f"{sys.argv[0]}?{urlencode({'action': 'tvshows_by_provider', 'provider_id': provider['provider_id'], 'provider_name': provider['provider_name'], 'page': 1})}"
        xbmcplugin.addDirectoryItem(handle, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(handle)

def show_by_provider(provider_id, provider_name, page=1):
    xbmcplugin.setPluginCategory(handle, f'Furnizor: {provider_name}')
    data = tmdb_tv.get_tv_by_provider(provider_id, page)
    if not data or 'results' not in data:
        xbmcgui.Dialog().notification('TMDb Browser', f'Eroare la furnizorul {provider_name}', xbmcgui.NOTIFICATION_ERROR)
        return
    for item in data['results']:
        details = tmdb_tv.get_tv_details(item['id'])
        li = build_item_tvshow(details)
        url = f'{sys.argv[0]}?action=tv_details&id={item["id"]}'
        xbmcplugin.setContent(handle, 'tvshows')
        xbmcplugin.addDirectoryItem(handle, url=url, listitem=li, isFolder=True)
    next_page = page + 1
    next_url = f"{sys.argv[0]}?{urlencode({'action': 'tvshows_by_provider', 'provider_id': provider_id, 'provider_name': provider_name, 'page': next_page})}"
    xbmcplugin.addDirectoryItem(handle, url=next_url, listitem=xbmcgui.ListItem(f'Pagina {next_page}'), isFolder=True)
    xbmcplugin.endOfDirectory(handle)

def show_seasons(tv_id):
    details = tmdb_tv.get_tv_details(tv_id)
    if not details or 'seasons' not in details:
        xbmcgui.Dialog().notification('TMDb Browser', 'Nu s-au găsit sezoane.', xbmcgui.NOTIFICATION_ERROR)
        return

    fanart = 'https://image.tmdb.org/t/p/w500' + (details.get('backdrop_path') or '')
    poster = 'https://image.tmdb.org/t/p/w500' + (details.get('poster_path') or '')

    for season in details['seasons']:
        name = season.get('name') or f"Sezonul {season['season_number']}"
        url = f"{sys.argv[0]}?{urlencode({'action': 'tv_season', 'tv_id': tv_id, 'season': season['season_number']})}"
        li = xbmcgui.ListItem(name)
        li.setArt({
            'thumb': 'https://image.tmdb.org/t/p/w500' + (season.get('poster_path') or details.get('poster_path') or ''),
            'fanart': fanart
        })
        xbmcplugin.addDirectoryItem(handle, url=url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(handle)

def show_episodes(tv_id, season_number):
    season = tmdb_tv.get_season(tv_id, season_number)
    details = tmdb_tv.get_tv_details(tv_id)
    if not season or 'episodes' not in season:
        xbmcgui.Dialog().notification('TMDb Browser', 'Nu s-au găsit episoade.', xbmcgui.NOTIFICATION_ERROR)
        return

    fanart = 'https://image.tmdb.org/t/p/w500' + (details.get('backdrop_path') or '')
    thumb_default = 'https://image.tmdb.org/t/p/w500' + (details.get('poster_path') or '')

    for ep in season['episodes']:
        name = ep.get('name') or f"Episodul {ep['episode_number']}"
        li = xbmcgui.ListItem(name)
        li.setProperty('IsPlayable', 'true')
        li.setArt({
            'thumb': 'https://image.tmdb.org/t/p/w500' + (ep.get('still_path') or details.get('poster_path') or ''),
            'fanart': fanart
        })
        url = f"plugin://plugin.video.tmdbbrowser/?action=play_episode&tv_id={tv_id}&season={season_number}&episode={ep['episode_number']}"
        xbmcplugin.addDirectoryItem(handle, url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(handle)

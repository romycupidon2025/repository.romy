### plugin.video.tmdbbrowser/default.py
import sys
import xbmcplugin
import xbmcaddon
import xbmcgui
from urllib.parse import parse_qs, urlparse

from resources.lib import player
from resources.lib.tmdb import api
from resources.lib.utils import get_icon_path
from resources.lib.menus import movies, tvshows

addon = xbmcaddon.Addon()
handle = int(sys.argv[1])

params = parse_qs(urlparse(sys.argv[2]).query)
xbmc.log(f"[TMDb Addon] Params: {params}", xbmc.LOGINFO)
action = params.get('action', [''])[0]
page = int(params.get('page', [1])[0])

if action == 'movies':
    movies.menu()
elif action == 'movies_popular':
    movies.show_popular(page)
elif action == 'movies_trending':
    movies.show_trending(page)
elif action == 'movies_genres':
    movies.show_genres()
elif action == 'movies_by_genre':
    genre_id = int(params.get('genre_id', [0])[0])
    genre_name = params.get('genre_name', [''])[0]
    movies.show_by_genre(genre_id, genre_name, page)
elif action == 'movies_years':
    movies.show_years()
elif action == 'movies_by_year':
    year = int(params.get('year', [2024])[0])
    movies.show_by_year(year, page)
elif action == 'movies_providers':
    movies.show_providers()
elif action == 'movies_by_provider':
    provider_id = int(params.get('provider_id', [0])[0])
    provider_name = params.get('provider_name', [''])[0]
    movies.show_by_provider(provider_id, provider_name, page)
elif action == 'movies_search':
    movies.search()
elif action == 'movies_search_results':
    query = params.get('query', [''])[0]
    movies.search_results(query)
elif action == 'tvshows':
    tvshows.menu()
elif action == 'tvshows_popular':
    tvshows.show_popular(page)
elif action == 'tvshows_trending':
    tvshows.show_trending(page)
elif action == 'tvshows_genres':
    tvshows.show_genres()
elif action == 'tvshows_by_genre':
    genre_id = int(params.get('genre_id', [0])[0])
    genre_name = params.get('genre_name', [''])[0]
    tvshows.show_by_genre(genre_id, genre_name, page)
elif action == 'tvshows_years':
    tvshows.show_years()
elif action == 'tvshows_by_year':
    year = int(params.get('year', [2024])[0])
    tvshows.show_by_year(year, page)
elif action == 'tvshows_providers':
    tvshows.show_providers()
elif action == 'tvshows_by_provider':
    provider_id = int(params.get('provider_id', [0])[0])
    provider_name = params.get('provider_name', [''])[0]
    tvshows.show_by_provider(provider_id, provider_name, page)
elif action == 'tvshows_search':
    tvshows.search()
elif action == 'tv_details':
    tv_id = int(params.get('id', [0])[0])
    tvshows.show_seasons(tv_id)
elif action == 'tv_season':
    tv_id = int(params.get('tv_id', [0])[0])
    season_number = int(params.get('season', [0])[0])
    tvshows.show_episodes(tv_id, season_number)
elif action == 'play_episode':
    tv_id = int(params.get('tv_id', [0])[0])
    season = int(params.get('season', [0])[0])
    episode = int(params.get('episode', [0])[0])
    player.play_tv_episode(handle, tv_id, season, episode)
elif action == 'play_movie':
    tmdb_id = int(params.get('tmdb_id', params.get('id', [0]))[0])
    player.play_movie(handle, tmdb_id)
else:
    xbmcplugin.setPluginCategory(handle, 'TMDb Browser')

    li = xbmcgui.ListItem('Filme')
    li.setArt({'thumb': get_icon_path('movies'), 'icon': get_icon_path('movies')})
    xbmcplugin.addDirectoryItem(handle, f'{sys.argv[0]}?action=movies', listitem=li, isFolder=True)

    li = xbmcgui.ListItem('Seriale')
    li.setArt({'thumb': get_icon_path('tvshows'), 'icon': get_icon_path('tvshows')})
    xbmcplugin.addDirectoryItem(handle, f'{sys.argv[0]}?action=tvshows', listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(handle)
